import experiment
import extension

def main():
    print("Starting Experiment...")
    #experiment.run()
    extension.run()


if __name__ == "__main__": main()