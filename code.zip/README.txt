experiment.py = original paper reimplementation
extension.py = extension regarding diverse populations
test.py = misc function testing
main.py = runs whichever test is uncommented